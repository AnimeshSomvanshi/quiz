package com.example.android.basiciq;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.View;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    // Submits the response and calculates the Score
    public void submit(View view) {
        int score = 0;
        String last = "";
        EditText e1 = (EditText) findViewById(R.id.ans1);
        String s1 = e1.getText().toString().trim();
        String ans1 = "integrated development environment";
        if (s1.equals(ans1)) {
            score += 1;
            last += "Answer 1 Correct\n";
        } else
            last += "Answer 1 Wrong\n";
        ;
        CheckBox c2 = (CheckBox) findViewById(R.id.checkbox2);
        Boolean check2 = c2.isChecked();
        CheckBox c1 = (CheckBox) findViewById(R.id.checkbox1);
        Boolean check1 = c1.isChecked();
        CheckBox c3 = (CheckBox) findViewById(R.id.checkbox3);
        Boolean check3 = c3.isChecked();
        if(check2 && check1 && !check3) {
            score += 1;
            last += "Answer 2 Correct\n";

        } else
            last += "Answer 2 Wrong\n";
        RadioButton r1 = (RadioButton) findViewById(R.id.radiobutton1);
        Boolean radio1 = r1.isChecked();
        RadioButton r2 = (RadioButton) findViewById(R.id.radiobutton2);
        Boolean radio2 = r2.isChecked();
        if (radio2 == true) {
            score += 1;
            last += "Answer 3 Correct\n";

        } else
            last += "Answer 3 Wrong\n";
        EditText e2 = (EditText) findViewById(R.id.ans4);
        String s2 = e2.getText().toString();
        String ans4 = "c++";
        if (s2.equals(ans4)) {
            score += 1;
            last += "Answer 4 Correct\n";

        } else
            last += "Answer 4 Wrong\n";

        EditText e3 = (EditText) findViewById(R.id.ans5);
        String s3 = e3.getText().toString();
        String ans5 = "programmer";
        if (s3.equals(ans5)) {
            score += 1;
            last += "Answer 5 Correct\n";

        } else
            last += "Answer 5 Wrong\n";

        Toast.makeText(MainActivity.this, last + "Score : " + score, Toast.LENGTH_LONG).show();


    }


}